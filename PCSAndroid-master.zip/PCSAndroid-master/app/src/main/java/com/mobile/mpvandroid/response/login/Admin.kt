package com.mobile.mpvandroid.response.login

data class Admin(
    val id: String,
    val email: String,
    val password: String,
    val nama: String
)
