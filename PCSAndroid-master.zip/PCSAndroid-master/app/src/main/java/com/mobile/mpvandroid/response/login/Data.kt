package com.mobile.mpvandroid.response.login

data class Data(
    val admin: Admin,
    val token: String
)
